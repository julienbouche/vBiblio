<html>
<head>
<title>Jennifer Lopez Bio</title>
</head>
<body>
<font size="2" face="verdana">

<?php
include('functions/amazon_functions.php');
$Data=amazon_search_actor("Jennifer Lopez","dvd");
echo amazon_create_teaserlist($Data,5,"","right","DVDs by Jennifer Lopez @amazon.com");
php?>

<img align="left" src="example3_jlo.jpg">

<big><b>Jennifer Lopez</b></big>

<p align=justify>Jennifer Lopez has in the past gotten more attention for the size of her backside than the quality of her work. But, in 1998 her career exploded - both in music and in film, finally overcoming the cult appeal of her rear end, although not completely curbing the amount of jokes and quotes devoted to her derriere.</p>

<p align=justify>Despite her Puerto Rican background, Jennifer Lopez was born right smack dab in the Bronx. She lived in the section they refer to as "Castle Hill," and being in the Bronx she had to take the 6 train to get to Manhattan for work, hence the name of her first album, "On the Six." Her parents are David Lopez, a computer specialist at Guardian Insurance, and her mother, a schoolteacher in New York. Both parents are from Puerto Rico, but raised Jennifer here in the United States. Jennifer has two sisters, Maria and Linda (an Entertainment Correspondent for WB Network in New York).</p>

<p align=justify>As Jennifer grew up, her body began to take the shape that is now world renknown. She was known as "La Guitarra" (Spanish for "The Guitar") because of the way her body shaped.</p>

<p align=justify>Jennifer moved to Manhattan to hone her dancing skills. The work would eventually pay off. Early on, Jennifer found work as a dancer on the hit show "In Living Color." For those who remember the show, it featured comedic skits interluded with musical numbers and beginning and ending with big dance numbers. Jennifer, was part of those big dance numbers. She also worked with Janet Jackson in vides and on her tours, including the video for "That's The Way Love Goes." A few film roles would eventually come in 1995, including "Money Train," "Jack," and "Mi Familia," none of which made too big a box office splash and none were able to make her a famous actress.</p>

<p align=justify>Her big break, however came in 1997, when she became the highest paid Latina movie star ever, bringing in a reported 1 million dollars for "Selena," the film portrayal of Salsa sensation Selena, who was murdered by the president of her fan club. From there, it was pretty much downhill.</p>

<p align=justify>[...]</p>

<small>� 1998-2001 <a href="http://www.absolutenow.com/" target="_blank">AbsoluteNow</a></small>

</font>
</body>
</html>