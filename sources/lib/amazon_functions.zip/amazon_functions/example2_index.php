<html>
<head>
<title></title>
<frameset rows="60,*" frameborder="0" framespacing="0" border="0">
<frame src="example2_top.php" name="top" noresize scrolling=no>
<frameset cols="225,*" frameborder="0" framespacing="0" border="0">
<frame src="example2_menu.php" name="menu" noresize>
<frame src="example2_content.php" name="content">
</frameset>
</frameset>
</head>
<body>
</body>
</html>